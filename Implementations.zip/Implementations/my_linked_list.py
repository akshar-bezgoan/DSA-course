#Our first linked list DS
from my_array import Array
"""
myLinkedList = {
	head: {
		value: 10,
		next: {
			value: 5,
			next: {
				value: 16,
				next: None
			}			
		}
	}
}
"""
class Node():
	def __init__(self, value):
		self.value = value
		self.next = None

class LinkedList():
	def __init__(self, value):
		newNode = Node(value)
		self.head = newNode
		self.tail = self.head
		self.length = 1
    
	def append(self, value): # O(1)
		newNode = Node(value)
		self.tail.next = newNode
		self.tail = newNode
		self.length += 1
		return self
    
	def prepend(self, value): # O(1)
		newNode = Node(value)
		newNode.next = self.head
		self.head = newNode
		self.length += 1        
		return None    
	def get_all(self):
		array = Array()  
		current = self.head
		while current is not None:
			array.push(current.value)
			current = current.next
		return array

	def insert(self, index, value):
		if index >= self.length:
			return self.append(value)
		
		newNode = Node(value)
		
		leader = self.traverse(index-1)
		
	def traverse(self, index):
		#TODO: check parameters
		
		counter = 0
		current = self.head
		
		while counter != index:
			current = current.next

	

		
		
		

myLinkedList = LinkedList(10)
myLinkedList.append(5)
myLinkedList.append(16)
myLinkedList.prepend(1)
print('head:', vars(myLinkedList.head))
print('tail:', vars(myLinkedList.tail))
print(myLinkedList.get_all().data)
print(vars(myLinkedList.insert(2,6)))
print('head:', vars(myLinkedList.head))
print('tail:', vars(myLinkedList.tail))
print(myLinkedList.get_all().data)


